import { Stream, ProviderContext } from "../types";

const headers = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
  "Referer": "https://www.tnaflix.com",
};

export async function getStream({
  link, providerContext,
}: { link: string; type: string; signal?: AbortSignal; providerContext: ProviderContext }): Promise<Stream[]> {
  try {
    const response = await providerContext.axios.get(link, { headers });
    const html = String(response.data || "");
    const $ = providerContext.cheerio.load(html);
    const candidates = new Set<string>();
    $("video[src], video source[src], source[src], a[href]").each((_, element) => {
      const raw = $(element).attr("src") || $(element).attr("href") || "";
      if (/^https?:\\/\\//i.test(raw) && /\\.(mp4|m3u8)(?:[?#]|$)/i.test(raw)) candidates.add(raw);
    });
    for (const match of html.matchAll(/https?:\\/\\/[^"'\\s<>]+?\\.(?:mp4|m3u8)(?:\\?[^"'\\s<>]*)?/gi)) {
      candidates.add(match[0].replace(/\\\\\\/g, ""));
    }
    return Array.from(candidates).map((url): Stream => ({
      server: "TNAFlix (page-exposed media)",
      link: url,
      type: url.toLowerCase().includes(".m3u8") ? "m3u8" : "mp4",
      headers,
    }));
  } catch (error: any) {
    console.warn("tnaflix stream extraction unavailable:", error?.message || error);
    return [];
  }
}
