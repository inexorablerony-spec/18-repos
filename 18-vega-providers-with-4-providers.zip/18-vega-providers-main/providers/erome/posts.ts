import { Post, ProviderContext } from "../types";

const BASE = "https://www.erome.com";
const headers = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Referer": BASE,
};

export async function getPosts({
  filter = "latest", page = 1, signal, providerContext,
}: {
  filter?: string; page?: number; signal?: AbortSignal; providerContext: ProviderContext;
}): Promise<Post[]> {
  return fetchPosts({ path: filter, page, signal, providerContext });
}

export async function getSearchPosts({
  searchQuery, page = 1, signal, providerContext,
}: {
  searchQuery: string; page?: number; signal?: AbortSignal; providerContext: ProviderContext;
}): Promise<Post[]> {
  return fetchPosts({ query: searchQuery, page, signal, providerContext });
}

async function fetchPosts({
  path, query, page, signal, providerContext,
}: {
  path?: string; query?: string; page: number; signal?: AbortSignal; providerContext: ProviderContext;
}): Promise<Post[]> {
  const { axios, cheerio } = providerContext;
  const url = query
    ? `${BASE}/search?q=${encodeURIComponent(query)}${page > 1 ? `&page=${page}` : ""}`
    : `${BASE}/${path && path !== "latest" ? path.replace(/^\\//, "") + "/" : ""}${page > 1 ? `page/${page}/` : ""}`;
  try {
    const response = await axios.get(url, { headers, signal });
    const $ = cheerio.load(response.data || "");
    const results: Post[] = [];
    const seen = new Set<string>();
    $("a").each((_, element) => {
      const a = $(element);
      const href = a.attr("href") || "";
      const img = a.find("img").first();
      const title = (a.attr("title") || img.attr("alt") || a.text() || "").trim();
      let image = img.attr("data-src") || img.attr("data-original") || img.attr("src") || "";
      if (!href || !title || !image) return;
      try {
        const link = new URL(href, BASE).href;
        image = new URL(image, BASE).href;
        if (seen.has(link) || !/^https?:/i.test(image)) return;
        seen.add(link);
        results.push({ title, link, image });
      } catch { return; }
    });
    return results.slice(0, 60);
  } catch (error: any) {
    console.warn("erome listing unavailable:", error?.message || error);
    return [];
  }
}
