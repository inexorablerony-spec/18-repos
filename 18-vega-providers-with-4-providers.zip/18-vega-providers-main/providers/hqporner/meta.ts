import { Info, ProviderContext } from "../types";

const headers = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
  "Referer": "https://hqporner.com",
};

export async function getMeta({
  link, providerContext,
}: { link: string; providerContext: ProviderContext }): Promise<Info> {
  const empty: Info = { title: "", image: "", synopsis: "", imdbId: "", type: "movie", linkList: [] };
  try {
    const response = await providerContext.axios.get(link, { headers });
    const $ = providerContext.cheerio.load(response.data || "");
    const pick = (selector: string) => $(selector).first().attr("content") || "";
    const title = pick('meta[property="og:title"]') || $("title").first().text().trim();
    const image = pick('meta[property="og:image"]') || "";
    const synopsis = pick('meta[name="description"]') || pick('meta[property="og:description"]') || "";
    return {
      title, image: image ? new URL(image, link).href : "", synopsis,
      imdbId: "", type: "movie",
      linkList: [{ title: "Open video page", quality: "Available on source site", episodesLink: link, directLinks: [] }],
    };
  } catch (error: any) {
    console.warn("hqporner metadata unavailable:", error?.message || error);
    return empty;
  }
}
