// Updated meta.ts with size extraction and linkList support

import { Info, Link, ProviderContext } from "../types";

const headers = {
  Accept:
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "Cache-Control": "no-store",
  "Accept-Language": "en-US,en;q=0.9",
  DNT: "1",
  "sec-ch-ua":
    '"Not_A Brand";v="8", "Chromium";v="120", "Microsoft Edge";v="120"',
  "sec-ch-ua-mobile": "?0",
  "sec-ch-ua-platform": '"Windows"',
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Sec-Fetch-User": "?1",
  Cookie:
    "xla=s4t; _ga=GA1.1.1081149560.1756378968; _ga_BLZGKYN5PF=GS2.1.s1756378968$o1$g1$t1756378984$j44$l0$h0",
  "Upgrade-Insecure-Requests": "1",
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
};

export const getMeta = async function ({ link, providerContext }: {
  link: string;
  providerContext: ProviderContext;
}): Promise<Info> {
  const { axios, cheerio } = providerContext;
  const url = link;
  const baseUrl = url.split("/").slice(0, 3).join("/");

  const emptyResult: Info = {
    title: "",
    synopsis: "",
    image: "",
    imdbId: "",
    type: "movie",
    linkList: [],
  };

  try {
    const response = await axios.get(url, {
      headers: { ...headers, Referer: baseUrl },
    });

    const $ = cheerio.load(response.data);
    const infoContainer = $(".entry-content").first();

    const result: Info = {
      title: "",
      synopsis: "",
      image: "",
      imdbId: "",
      type: "movie",
      linkList: [],
    };

    // Title
    const rawTitle = $("h1.page-title").text().trim();
    result.title = rawTitle.replace(/\(\d{4}\)|\d+p|HQ HDTC|\|/g, "").trim();
    if (!result.title) result.title = "Unknown Title";

    // IMDb ID
    result.imdbId = "";

    // Main poster image
    let image = infoContainer.find("img[src]").first().attr("src") || "";
    if (image.startsWith("//")) image = "https:" + image;
    if (image.includes("placeholder") || image.includes("no-thumbnail")) image = "";
    result.image = image;

    // Synopsis
    const synopsisHeading = infoContainer.find(
      "h4:contains('synopsis'):contains('PLOT')"
    ).first();
    result.synopsis = synopsisHeading.next("p").text().trim() || "";

    // -----------------------
    // DOWNLOAD LINK EXTRACTION
    // Now supports: <h4> + <p> format
    // -----------------------

    const links: Link[] = [];

infoContainer.find("h3, h4, h5").each((i, el) => {
  const titleEl = $(el as any);
  const blockTitle = titleEl.text().trim();
  const tagName = (el as any).tagName?.toLowerCase();

  if (tagName === "h3" || tagName === "h4" || tagName === "h5") {
    const nextEl = titleEl.next();

    // Find the element after title — could be <p> or another <h4>
    const linkContainer =
      nextEl.is("p") ? nextEl :
      nextEl.find("a").length ? nextEl :
      null;

    if (!linkContainer) return;

    // Try V-Cloud first
    const vcloudLink = linkContainer.find("a").filter((i, a) =>
      $(a).text().toLowerCase().includes("v-cloud")
    );

    let finalUrl = "";
    let finalTitle = "";

    if (vcloudLink.length) {
      // Priority: V-Cloud found
      finalUrl = vcloudLink.attr("href") || "";
      finalTitle = "V-Cloud";
    } else {
      // Fallback: Any <a> inside (Download Now type)
      const fallback = linkContainer.find("a").first();
      if (!fallback.length) return;

      finalUrl = fallback.attr("href") || "";
      finalTitle = fallback.text().trim() || "Download";
    }

    // Push to output
    links.push({
      title: blockTitle,
      quality: "",
      episodesLink: finalUrl,
      directLinks: [
        {
          title: finalTitle,
          link: finalUrl,
          type: "movie",
        },
      ],
    });

    return;
  }


  // -----------------------------------------
  // ✔️ H4 / H5 processing
  // -----------------------------------------
  if (
    !blockTitle.includes("480p") &&
    !blockTitle.includes("720p") &&
    !blockTitle.includes("1080p") &&
    !blockTitle.includes("2160p")
  ) return;

  const qualityMatch =
    blockTitle.match(/(480p|720p|1080p|2160p)/)?.[0] || "";

  const sizeMatch = blockTitle.match(/\[(.*?)\]/)?.[1] || "";

  const nextP = titleEl.next("p");
  const aTag = nextP.find("a");
  const href = aTag.attr("href") || "";

  if (!href) return;

  const directLinks: Link["directLinks"] = [
    {
      title: sizeMatch ? `${qualityMatch} (${sizeMatch})` : qualityMatch,
      link: href,
      type: "movie",
    },
  ];

  links.push({
    title: blockTitle,
    quality: qualityMatch,
    episodesLink: href,
    directLinks,
  });
});
    result.linkList = links;
    return result;
  } catch (err) {
    console.log("getMeta error:", err);
    return emptyResult;
  }
};
