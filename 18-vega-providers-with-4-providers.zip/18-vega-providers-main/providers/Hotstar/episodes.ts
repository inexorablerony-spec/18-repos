import { ProviderContext } from "../types";

const MAIN_URL = "https://net52.cc";
const UA = "Mozilla/5.0 (Linux; Android 13; Pixel 5 Build/TQ3A.230901.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/144.0.7559.132 Safari/537.36 /OS.Gatu v3.0";

async function getBypassCookie(axios: any): Promise<string> {
  for (let attempt = 0; attempt < 10; attempt++) {
    try {
      const res = await axios.post(`${MAIN_URL}/tv/p.php`, null, {
        headers: {
          "User-Agent": UA,
          "X-Requested-With": "XMLHttpRequest",
          "Referer": `${MAIN_URL}/home`,
        },
      });

      const dataStr = typeof res.data === "string" ? res.data : JSON.stringify(res.data);
      if (dataStr.includes('"r":"n"')) {
        const sc = res.headers["set-cookie"];
        if (sc) {
          const raw = Array.isArray(sc) ? sc.join(";") : sc;
          const match = raw.match(/t_hash_t=([^;]+)/);
          if (match) return match[1];
        }
      }
    } catch (e) {}
  }
  return "";
}

export async function getEpisodes({
  url,
  providerContext,
}: {
  url: string;
  providerContext: ProviderContext;
}): Promise<{ title: string; link: string; image?: string }[]> {
  const { axios } = providerContext;
  const [seriesId, seasonId, title] = url.split("|");
  const unixTime = Math.floor(Date.now() / 1000);

  // Directly handle Movies
  if (!seasonId) {
    return [
      {
        title: "Full Movie",
        link: `${seriesId}|${title}`,
        image: `https://imgcdn.kim/hs/v/${seriesId}.jpg`,
      },
    ];
  }

  const hash = await getBypassCookie(axios);
  const episodes: any[] = [];
  let page = 1;

  while (true) {
    const api = `${MAIN_URL}/mobile/hs/episodes.php?s=${seasonId}&series=${seriesId}&t=${unixTime}&page=${page}`;

    try {
      const res = await axios.get(api, {
        headers: {
          "User-Agent": UA,
          "X-Requested-With": "XMLHttpRequest",
          "Referer": `${MAIN_URL}/home`,
          "Cookie": `t_hash_t=${hash}; ott=hs; hd=on`,
        },
      });

      const data = res.data;

      if (!data?.episodes || !Array.isArray(data.episodes) || data.episodes.length === 0) {
        break;
      }

      data.episodes.forEach((ep: any) => {
        if (!ep?.id) return;

        const epNum = ep.ep ? ep.ep.toString().replace(/\D/g, "") : "";
        const epName = ep.t || `Episode ${epNum}`;

        episodes.push({
          title: epNum ? `E${epNum} - ${epName}` : epName,
          link: `${ep.id}|${title}`,
          image: `https://imgcdn.kim/hsepimg/150/${ep.id}.jpg`,
        });
      });

      if (data.nextPageShow === 0) break;
      page++;
    } catch (e) {
      console.error("Hotstar getEpisodes error:", e);
      break;
    }
  }

  return episodes;
}